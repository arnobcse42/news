<?php $__env->startSection('content'); ?>
	<section class="container news-container">
    <div class="col-sm-9">
    
    <div class="row">
      <div class="col-sm-12">
        <?php echo e($news->links()); ?>

      </div>
    </div>
    
    
    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row news-list">
      <div class="col-sm-3">
        <a href="<?php echo e(url('news/detail/'.$n->id)); ?>" class="thumbnail">
          <img class="img" src="<?php echo e(asset('storage/'.$n->news_img)); ?>" alt="<?php echo e($n->news_title); ?>">
        </a>
      </div>
      <div class="col-sm-9">
        <h2><?php echo e($n->news_title); ?></h2>
        <p class="margin-top10"><?php echo e(str_limit($n->news_desc,200,'...')); ?></p>
        <p>
          <a href="<?php echo e(url('news/detail/'.$n->id)); ?>" class="btn btn-sm btn-info">Read More...</a>
        </p>
      </div>
    </div>
    <hr />
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    
    <div class="row">
      <div class="col-sm-12">
        <?php echo e($news->links()); ?>

      </div>
    </div>
    
  </div>
  <?php echo $__env->make('news.right-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>