<div class="col-sm-3">
	<div class="list-group">
		<a href="<?php echo e(url('admin')); ?>" class="list-group-item <?php echo e(Request::is('admin') ? 'active' : ''); ?>">News</a>
		<a href="<?php echo e(url('admin/category')); ?>" class="list-group-item <?php echo e(Request::is('admin/category') ? 'active' : ''); ?>">Categories</a>
	</div>
</div>