<?php $__env->startSection('content'); ?>
	<section class="container news-container">
    <div class="col-sm-9">
    
    <div class="row news-list">
      <h3>
        <?php echo e($newsDetail[0]->news_title); ?>

      </h3>
      <img class="img margin-top20" src="<?php echo e(asset('storage/'.$newsDetail[0]->news_img)); ?>" alt="<?php echo e($newsDetail[0]->news_title); ?>">
      <p class="margin-top10">
        <?php echo e($newsDetail[0]->news_desc); ?>

      </p>
    </div>
    <hr />
    
  </div>
  <?php echo $__env->make('news.right-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>