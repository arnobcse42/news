<?php $__env->startSection('content'); ?>
<section class="container" style="margin-top:85px;">
	<div class="row">
		<?php echo $__env->make('admin/left-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<div class="col-sm-9">
			<?php if($errors->any()): ?>
			<div class="alert alert-danger">
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<p><?php echo e($error); ?></p>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			<?php endif; ?>
			<?php if(Session::has('success')): ?>
			<p class="alert alert-warning"><?php echo e(session('success')); ?></p>
			<?php endif; ?>
			<h3 class="border-bottom" style="margin-bottom:20px;">Add Category <a href="<?php echo e(url('admin/category')); ?>" class="pull-right btn btn-success btn-xs">
			<span class="glyphicon glyphicon-arrow-left"></span> Category List</a></h3>
			<table class="table table-bordered display table-hover" id="dataTable">
				<form action="<?php echo e(url('admin/category/store_category')); ?>" method="post">
					<?php echo e(csrf_field()); ?>

					<tr>
						<th>Title</th>
						<td><input type="text" class="form-control" placeholder="Title" name="_title" /></td>
					</tr>
					<tr>
						<td colspan="2">
							<input type="submit" value="Add Data" class="btn btn-danger" />
						</td>
					</tr>
				</form>
			</table>
		</div>
	</div>
</section>
<script type="text/javascript" src="<?php echo e(asset('lib/ckeditor/ckeditor.js')); ?>"></script>
<script type="text/javascript">
	CKEDITOR.replace('editor');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>