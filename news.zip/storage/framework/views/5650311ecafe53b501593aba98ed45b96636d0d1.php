<div class="col-sm-3">
	<div class="list-group">
		<a href="<?php echo e(url('admin')); ?>" class="list-group-item">News</a>
		<a href="<?php echo e(url('admin/category')); ?>" class="list-group-item">Categories</a>
	</div>
</div>